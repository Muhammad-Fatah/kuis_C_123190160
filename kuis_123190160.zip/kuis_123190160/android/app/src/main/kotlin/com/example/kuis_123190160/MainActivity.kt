package com.example.kuis_123190160

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
