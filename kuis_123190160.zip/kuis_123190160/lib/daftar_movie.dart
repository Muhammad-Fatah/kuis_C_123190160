
import 'package:flutter/material.dart';

class DaftarMovie extends StatelessWidget {
  final String original_language, original_title, trailer, overview, poster_path, release_date, title;


  const DaftarMovie(
      {Key? key,
        required this.original_language,
        required this.original_title,
        required this.trailer,
        required this.overview,
        required this.poster_path,
        required this.release_date,
        required this.title,
      }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("$original_title")
      ),
      body: Container(
        child: Center(
          child: Column(
            children: [
              Image.network(poster_path),
              Text("$title"),
              Text("$release_date"),
              Text("$original_language"),
              // Text("$songs",
              // style: TextStyle(color: Colors.red),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
